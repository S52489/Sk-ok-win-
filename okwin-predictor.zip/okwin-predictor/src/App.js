
import React, { useState } from 'react';
import './App.css';

const getColor = (num) => {
  if ([0, 5].includes(num)) return 'Violet';
  if ([1, 3, 7, 9].includes(num)) return 'Green';
  if ([2, 4, 6, 8].includes(num)) return 'Red';
  return 'Unknown';
};

const getBigSmall = (num) => {
  if (num >= 5) return 'Big';
  return 'Small';
};

const mostFrequentNumber = (numbers) => {
  const freq = {};
  numbers.forEach((n) => {
    freq[n] = (freq[n] || 0) + 1;
  });
  return Object.entries(freq).reduce((a, b) => (a[1] > b[1] ? a : b))[0];
};

function App() {
  const [numbers, setNumbers] = useState([7, 0, 6, 7, 3, 7, 9, 2, 6, 2]);
  const latest = numbers[numbers.length - 1];
  const prediction = {
    bigSmall: getBigSmall(latest),
    color: getColor(latest),
    likelyNumber: mostFrequentNumber(numbers),
  };

  const handleAdd = () => {
    const newNum = Math.floor(Math.random() * 10);
    setNumbers([...numbers, newNum]);
  };

  return (
    <div className="App">
      <h1>OKWin Predictor</h1>
      <p>Last Number: <strong>{latest}</strong></p>
      <p>Prediction: <strong>{prediction.bigSmall}</strong> - <strong>{prediction.color}</strong></p>
      <p>Most Likely Number: <strong>{prediction.likelyNumber}</strong></p>
      <button onClick={handleAdd}>Add Random Number</button>
      <div style={{ marginTop: 20 }}>
        {numbers.map((num, index) => (
          <span key={index} style={{ margin: '0 5px' }}>{num}</span>
        ))}
      </div>
    </div>
  );
}

export default App;
